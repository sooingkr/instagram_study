# Experimental

The directory contains the same examples as the top-level `javascript` and `typescript` directories. The main difference is that it uses **Prisma Migrate** to perform database migrations. **Prisma Migrate is currently in an experimental state.**
