module.exports = {
  ...require('./AuthPayload'),
  ...require('./Mutation'),
  ...require('./Post'),
  ...require('./Query'),
  ...require('./User'),
}
