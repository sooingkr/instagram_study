# ZEIT Now

[![Deploy with ZEIT Now](https://zeit.co/button)](https://zeit.co/new/project?template=https://github.com/prisma/prisma-examples/tree/prisma2-deployment-zeit/deployment-platforms/zeit-now)


[Deployment guide](#link-to-docs)