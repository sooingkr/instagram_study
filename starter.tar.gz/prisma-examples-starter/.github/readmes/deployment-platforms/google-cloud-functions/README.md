# Google Cloud Functions

## Deployment

__INLINE(../_setup-1-no-swap.md)__

## Environment

__INLINE(../_setup-5-env.md)__

https://cloud.google.com/functions/docs/env-var