### 5. Start the gRPC server

```
npm run dev
```

The server is now running on `0.0.0.0:50051`. 