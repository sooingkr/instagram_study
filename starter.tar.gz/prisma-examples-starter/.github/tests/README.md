# Tests

This internal directory defines test scripts for our CI. Each project gets its
own test script, but we use this hidden directory so we don't need to define it
in each public project, since users checking out our examples don't care about
that.
