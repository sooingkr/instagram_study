#!/bin/sh

set -eu

yarn dev
