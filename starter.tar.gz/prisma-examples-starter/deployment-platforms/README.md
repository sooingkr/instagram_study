# Deployment platforms

Prisma 2 in several deployment environments.
